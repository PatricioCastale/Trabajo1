package ar.org.centro8.curso.java.entities;

public class radio {
    @Override
    public String toString() {
        return " [marca=" + marca + "]";
    }

    public radio(String marca) {
        this.marca = marca;
    }

    String marca;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void cambiar() {

    }
}
