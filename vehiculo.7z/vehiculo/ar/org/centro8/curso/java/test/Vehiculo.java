package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.clasic;
import ar.org.centro8.curso.java.entities.modern;
import ar.org.centro8.curso.java.entities.radio;

public class Vehiculo {
  public static void main(String[] args) {

    clasic auto1 = new clasic("ford", "b365",
        "morado");
    modern auto2 = new modern("Renaul", "Gringer54",
        "mate", new radio("Noblex"));
    clasic auto3 = new clasic("Gorgon", "YU23",
        "Magenta", 1200000);
    clasic auto4 = new clasic("Porche", "KT4",
        "Gold", 5100000, new radio("Forsaquen"));
    modern auto5 = new modern("Chevrolet", "GE456",
        "Gray", 3000000, new radio("Sansei"));
    clasic auto6 = new clasic("Ferrari", "Base0",
        "Yellow", new radio("Obristan"));
    clasic auto7 = new clasic("Sonier", "Falcon",
        "green", null);

    auto1.frenar();
    auto2.arranca();
    auto5.cambiarradio();
    auto7.colocarradio();

    System.out.println(auto1.toString());
    System.out.println(auto2.toString());
    System.out.println(auto3.toString());
    System.out.println(auto4.toString());
    System.out.println(auto5.toString());
    System.out.println(auto6.toString());
    System.out.println(auto7.toString());
  }
}
