package ar.org.centro8.curso.java.entities;

import java.util.Scanner;

public class modern {

    Scanner tcl = new Scanner(System.in);

    public modern(String marca, String modelo, String color, radio rad1) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.rad1 = rad1;
    }

    public modern(String marca, String modelo, String color, int precio, radio rad1) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.rad1 = rad1;
    }

    @Override
    public String toString() {
        return "modern [color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio + ", radio="
                + rad1 + "]";
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public radio getRad1() {
        return rad1;
    }

    public void setRad1(radio rad1) {
        this.rad1 = rad1;
    }

    String marca;
    String modelo;
    String color;
    int precio;
    radio rad1;

    public void arranca() {

    }

    public void cambiarradio() {
        String mod;
        System.out.println("Ingrese la nueva radio");
        mod = tcl.next();
        rad1 = new radio(mod);
    }
}
